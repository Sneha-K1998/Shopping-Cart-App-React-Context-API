const itemData = [
  {
    id: 1,
    name: "T-shirt",
    price: 100,
  },
  {
    id: 2,
    name: "Pants",
    price: 200,
  },
  {
    id: 3,
    name: "Shoes",
    price: 300,
  },
  {
    id: 4,
    name: "Hat",
    price: 400,
  },
  {
    id: 5,
    name: "Socks",
    price: 500,
  },
];

export default itemData;
